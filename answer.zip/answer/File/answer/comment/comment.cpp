#include <string.h>
#include<bits/stdc++.h>
using namespace std;

int main()
{
 //char s[100]="float a=b int b+c=d //arpa";
 ifstream inputFile("input.txt");

    if (!inputFile.is_open()) {
        cerr << "Error opening file!" << endl;
        return 1;
    }
    string s;
printf("Comments are : \n");
while(getline(inputFile,s)){

    int l = s.size();
    for(int i=0; i<l; i++){
        if(s[i]=='/'){
            i++;
            while(i<l){
                if(s[i]=='*' ||s[i]=='/'){
                    i++;
                    continue;
                }
                printf("%c",s[i++]);
            }
            printf("\n");
        }
    }

}

 return 0;
}

