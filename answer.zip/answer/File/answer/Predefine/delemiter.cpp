#include <string.h>
#include <stdio.h>
int main ()
{
    char str[100]="int a=b+c/5*6-8";
    //printf("Enter The Statement: ");
    //gets(str);
    char s[20] = {' ','-','+','*','/',',',';','>','<','=','(',')','[',']','{','}'};
    char *token;
int i,j;
printf("\nThe Delemiters Are:");
 for(i=0;i<strlen(str);i++) {
            for(j=0;j<20;j++){
                    if(str[i]==s[j]){
                        printf("%c",s[j]);
                    }
            }
 }
    token = strtok(str, s);
    printf("\nStatement Without Delimiters\n");

    while( token != NULL )
    {
        printf( " %s ", token );
        token = strtok(NULL, s);
    }
    return(0);
}
