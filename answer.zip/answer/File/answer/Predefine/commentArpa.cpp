#include <string.h>
#include <stdio.h>

int main()
{
 char s[100]="int a+b=c; float b+6=c /*plus minus*/";
 //printf("Enter a statemnet with comment: ");
 //gets(s);
 int l = strlen(s);
 printf("comments present in the statement are: \n");
    for(int i=0;i<l;i++){
        if(s[i]=='/'){
            i++;
            while(i<l){
                if(s[i]=='*' ||s[i]=='/'){
                    i++;
                    continue;
                }
                printf("%c",s[i++]);
            }
        }
    }
 return 0;
}

