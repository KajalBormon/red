#include<bits/stdc++.h>
using namespace std;
int main()
{
 set<string>st={"\,","\;","{","}"};
 ifstream inputFile("input.txt");
 if(!inputFile.is_open()){
    cout<<"Error opening file!"<<endl;
    return 1;
 }
 string s;
 cout<<"Delimiters present in the statement are:\n";
 while(getline(inputFile,s)){
    int l=s.size(),i=0;
    while(i<l){
    string tmp="";
    tmp+=s[i];
    if(st.find(tmp)!=st.end())
        cout<<s[i]<<"\n";
    i++;
}
 }
  inputFile.close();

 return 0;
}
