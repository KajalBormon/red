#include<bits/stdc++.h>
using namespace std;
int main(){
ifstream inputFile("input.txt");
if(!inputFile.is_open()){
    cout<<"Error for opening file!"<<endl;
    return 1;
}
    string s;
     cout<<"Comments present in the statement are: \n";
    while(getline(inputFile,s)){
        int l=s.size();
        for(int i=0;i<l;i++){
            if(s[i]=='/'){
                i++;
                while(i<l){
                    if(s[i]=='*'||s[i]=='/'){
                        i++;
                        continue;
                    }
                    cout<<s[i++];
                }
                cout<<"\n";
            }
        }
    }
    inputFile.close();
}
