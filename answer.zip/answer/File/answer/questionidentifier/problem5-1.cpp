#include <bits/stdc++.h>
using namespace std;
int main() {
    bool iscomment = false, multiline = false;
    string keywo[] = {"main","void","int", "float","string","scanf", "printf", "if", "else", "while", "for", "return"};
    int count = 0;
    string line;
    set<string>identifierFounded;
    ifstream myfile("problem5.txt");
    while(getline(myfile, line)){
        bool key_word=false;
        string str = "";
        int s=0, i=0, l=line.length();
        count++;
      
       
        while (i<l)
        {
            //check comment
            if(line[i]=='/' && line[i+1] == '/' && multiline == false){
            i=l;
            }
            else if(line[i]=='/' && line[i+1] == '*' || multiline == true){
            iscomment = true;
            int j=i+2;
            if(multiline == true){
                    j=0;
                }
            for(i=j;i<l;i++){
                
            if(line[i]=='*' && line[i+1] == '/'){
                iscomment = false;
                multiline = false;
                
                i=i+2;
                break;
            }
            if(iscomment){
                
                if(i==l-1){
                    multiline = true;
                    
                }
            }

            }
        }



            if(line[i]=='\'' || line[i]=='"'){
                if(s==0){
                    s=1; 
                }   
                else{
                    s=0;
                }
                i++;
            }
            else if(isalpha(line[i]) || isalnum(line[i]) || line[i]=='_' ){
                if(s==0){
                    str+=line[i];           
                }
                i++;
            }
            else{
                if(!str.empty()){
                    //check keyword
                    for(int k=0;k<12;k++){
                        if(keywo[k]==str ){
                            key_word=true;
                            break;
                        }
                    }
                    if(key_word==false && str[0]!='1' && str[0]!='2' && str[0]!='3' && str[0]!='4' && str[0]!='5' && str[0]!='6' && str[0]!='7' && str[0]!='8' && str[0]!='9' && str[0]!='0'){
                       //cout<<str<<"\t";   
                       identifierFounded.insert(str);            
                    }
                }
                key_word=false;
                str="";
                i++;
            }
        }
        

    }
  cout<<"All identifier :"<<endl;
    for(auto i: identifierFounded)
        {
            cout<<i<<endl;
        }

    myfile.close();

    return 0;
}
