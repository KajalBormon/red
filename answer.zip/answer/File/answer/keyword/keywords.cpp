#include<bits/stdc++.h>
using namespace std;
int main()
{
    set<string> keywords = {"for", "while", "int", "float", "string", "char", "return","if","else","break","case","const","continue","default","do","double","enum","extern","goto","long","register","short","signed","sizeof","static","struct","switch","typedef","union","unsigned","void","volatile"};
    // Open the input file
    ifstream inputFile("input.txt");


    // Check if the file is opened successfully
    if (!inputFile.is_open())
    {
        cerr << "Error opening file!" << endl;
        return 1;
    }
    string s;
    // Read each line from the file
    cout << "Keyword(s) present in the statement are: \n";
    while (getline(inputFile, s))
    {
        int l = s.size(), i = 0;
        while (i < l)
        {
            string tmp = "";
            while (s[i] != ' ' && i < l)
                tmp += s[i++];
            if (keywords.find(tmp) != keywords.end())
                cout << tmp << "\n";
            if (s[i] == ' ')
                i++;
        }
    }
    // Close the input file
    inputFile.close();

    return 0;
}
