#include<bits/stdc++.h>
using namespace std;
int main()
{
    /*char str[100];
    int n,i;
    scanf("%[^\n]%*c", str);
    n= strlen(str);*/

    ifstream inputFile("input.txt");
    if (!inputFile.is_open()) {
        cerr << "Error opening file!" << endl;
        return 1;
    }
    string str;
    while(getline(inputFile,str)){
    int n = str.size(), i;
    for(i=0; i<=n; i++)
    {
        if(str[i]=='='&&str[i+1]=='='||
                str[i]=='!'&&str[i+1]=='='||
                str[i]=='>'&&str[i+1]=='='||
                str[i]=='<'&&str[i+1]=='=')
        {
            printf("%c%c is a Relational operator\n",str[i],str[i+1]);
        }
        else if(str[i]=='<'|| str[i]=='>')
        {
            printf("%c is a Relational operator\n",str[i]);
        }
    }
}
    return 0;
}
