#include <string.h>
#include <stdio.h>

int main()
{
 char s[100];
 printf("Enter a statemnet with comment: ");
 gets(s);
 int l = strlen(s);
 printf("Delimiters present in the statement are: \n");
    for(int i=0;i<l;i++){
        if(s[i]=='/'){
            i++;
            while(i<l){
                if(s[i]=='*' ||s[i]=='/'){
                    i++;
                    continue;
                }
                printf("%c",s[i++]);
            }
        }
    }
 return 0;
}

