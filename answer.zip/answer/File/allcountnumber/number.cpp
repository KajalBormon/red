#include<bits/stdc++.h>
using namespace std;
bool isDelimeter(char a){
char delimeter[5]={' ',',',';','(',')'};
for(int i=0;i<5;i++){
    if(a==delimeter[i])
        return true;
    }
}
int main(){
ifstream inputFile("input.txt");
if(!inputFile.is_open()){
    cout<<"Error openinbg file";
    return 1;
}
string s;
cout<<"numbers present in the statement are:";
while(getline(inputFile,s)){
        int l=s.size();
    string tmp="";
for(int i=0;i<l;i++){
    if(isdigit(s[i])){
        tmp+=s[i];
    }
    else if(isDelimeter(s[i])){
        if(tmp!=""){
            cout<<tmp<<" is a number\n";
        }
        tmp="";
    }
}

}
inputFile.close();
return 0;
}



